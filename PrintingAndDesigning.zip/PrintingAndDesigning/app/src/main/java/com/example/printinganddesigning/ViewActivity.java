package com.example.printinganddesigning;


        import androidx.appcompat.app.AlertDialog;
        import androidx.appcompat.app.AppCompatActivity;

        import android.database.Cursor;
        import android.os.Bundle;
public class ViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        Database db = new Database(this);

        Cursor select = db.getCustomer();

        StringBuffer buffer = new StringBuffer();
        int y = 1;
        while(select.moveToNext()){
            buffer.append(y+" Customer\n");
            buffer.append("\nCustomer Name : "+ select.getString(1));
            buffer.append("\nAddress. : "+ select.getString(0));
            buffer.append("\nPhone No : "+ select.getString(2));
            buffer.append("\nPassword : "+ select.getString(3));
            buffer.append("\n\n\n");
            y++;
        }
        showMessage("Registered Customer",buffer.toString());

    }
    public void showMessage(String title, String messange){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.create();
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(messange);
        builder.show();
    }
}