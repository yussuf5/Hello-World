package com.example.sharedintent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText name, user, pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = (EditText) findViewById(R.id.name);
        user = (EditText) findViewById(R.id.user);
        pass = (EditText) findViewById(R.id.pass);

    }

    public void save(View s){

        SharedPreferences xshare = getSharedPreferences("shared", MODE_PRIVATE);
        SharedPreferences.Editor xed = xshare.edit();
        xed.putString("name", name.getText().toString());
        xed.putString("username", user.getText().toString());
        xed.putString("password", pass.getText().toString());
        xed.commit();

        // Mbwembwe....
        name.setText("");
        pass.setText("");
        user.setText("");
        name.requestFocus();

        Toast.makeText(MainActivity.this, "Your data has been saved..",
                Toast.LENGTH_LONG).show();

    }

    public void retr(View a){

        Intent x = new Intent(MainActivity.this, Displaying.class);
        startActivity(x);

    }

    public void cleee(View vi){

        SharedPreferences clearr = getSharedPreferences("shared", MODE_PRIVATE);
        SharedPreferences.Editor xx = clearr.edit();
        xx.putString("name", "");
        xx.putString("username", "");
        xx.putString("password", "");
        xx.commit();

        Toast.makeText(MainActivity.this, "Your data has been cleared..",
                Toast.LENGTH_LONG).show();

    }



}