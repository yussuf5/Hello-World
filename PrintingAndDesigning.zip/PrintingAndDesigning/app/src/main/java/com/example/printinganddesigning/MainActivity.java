package com.example.printinganddesigning;



        import androidx.appcompat.app.AppCompatActivity;

        import android.content.Intent;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText name, add, phone, pass;
    Button sub, view;

    Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new Database(this);

        name = (EditText)findViewById(R.id.name);
        add = (EditText)findViewById(R.id.add);
        phone = (EditText)findViewById(R.id.phone);
        pass = (EditText)findViewById(R.id.pass);

        sub = (Button) findViewById(R.id.sub);
        view = (Button) findViewById(R.id.view);

//        final String stname = name.getText().toString();
//        final String streg = add.getText().toString();
//        final String stphone = phone.getText().toString();
//        final String stdob = pass.getText().toString();

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stname = name.getText().toString();
                String stradd = add.getText().toString();
                String stphone = phone.getText().toString();
                String stpass = pass.getText().toString();

                if(stname.equals(' ')&& stradd.equals(' ')&&stphone.equals(' ')&&stpass.equals(' '))
                    Toast.makeText(getApplicationContext(), "Customer not inserted", Toast.LENGTH_SHORT).show();
                else{
                    boolean insert = db.InsertCustomer(stname, stradd,stphone,stpass);
                    if (insert){
                        name.setText("");
                        add.setText("");
                        phone.setText("");
                        pass.setText("");
                        Toast.makeText(getApplicationContext(), "Customer inserted", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(getApplicationContext(), "Customer not inserted", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent next = new Intent(MainActivity.this,ViewActivity.class);
                startActivity(next);
            }
        });


    }



}