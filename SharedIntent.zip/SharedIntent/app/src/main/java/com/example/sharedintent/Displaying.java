package com.example.sharedintent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class Displaying extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_displaying);

        TextView name = (TextView) findViewById(R.id.d_name);
        TextView user = (TextView) findViewById(R.id.user_d);
        TextView pass = (TextView) findViewById(R.id.d_pass);

        SharedPreferences xd = getSharedPreferences("shared", MODE_PRIVATE);

        name.setText(xd.getString("name", ""));
        user.setText(xd.getString("username", ""));
        pass.setText(xd.getString("password", ""));

    }
}