package com.example.printinganddesigning;




        import android.content.ContentValues;
        import android.content.Context;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;
        import android.database.sqlite.SQLiteOpenHelper;

        import androidx.annotation.Nullable;

public class Database extends SQLiteOpenHelper {
    public Database(@Nullable Context context) {
        super(context, "mydata", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table customer (phone text primary key, name text, address text, pass text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists customer");
        onCreate(db);
    }

    public boolean InsertCustomer(String phone, String name, String address, String pass){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("add", address);
        cv.put("phone", phone);
        cv.put("pass", pass);
        long result = db.insert("customer", null, cv);
        if(result == -1){
            return false;
        }else{
            return true;
        }
    }
    public Cursor getCustomer(){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "select * from customer";
        return db.rawQuery(query, null);
    }

}